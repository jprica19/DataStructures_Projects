package edu.uwp.cs.csci242.assignments.a04.recursion;

import java.util.Scanner;
/**
 * Main method will extend the Recursion class
 * </p>
 * The main method will call each recursive methods
 * in order, and display the proper solutions to the user.
 **/


public class Main extends Recursion {
    public static void main(String[] args) {
        // Initialize a scanner to enable keyboard input
        Scanner in = new Scanner(System.in);

        // Method 1 call
        String result1 = "yyzzza";
        System.out.println(stringClean (result1));

        // Method 1 call
        String result2 = "abbbcdd";
        System.out.println(stringClean(result2));

        // Method 1 call
        String result3 = "Hello";
        System.out.println(stringClean(result3));
        System.out.println();

        // Method 2 call
        System.out.println(countDigit (222,2));
        System.out.println(countDigit (123414, 1));
        System.out.println(countDigit ( 123414, 5));
        System.out.println();

        // Method 3 call
        System.out.println(Recursion.isBalanced("(){}[]"));
        System.out.println(Recursion.isBalanced(""));
        System.out.println(Recursion.isBalanced("()"));
        System.out.println(Recursion.isBalanced("()()"));
        System.out.println(Recursion.isBalanced("(())"));
        System.out.println(Recursion.isBalanced("((){})[]"));
        System.out.println(Recursion.isBalanced("()[{}][]"));
        System.out.println(Recursion.isBalanced("(()())((()))((()))"));
        System.out.println(Recursion.isBalanced("{(})"));
        System.out.println((Recursion.isBalanced(")(")));
        System.out.println("\n\n");

        // Initialize 4 separate integer arrays
        // These arrays will be needed for the next method call
        int [] array1 = {2,2};
        int [] array2 = {2, 3};
        int [] array3 = {5,2,3};
        int[] array4 = {2,5,3};

        // Method 4 call
        System.out.println(splitArray(array1));
        System.out.println(splitArray(array2));
        System.out.println(splitArray(array3));
        System.out.println(splitArray(array4));


        char pegA = 'A';
        char pegB = 'B';
        char pegC = 'C';

        // Method 5 call
        System.out.println("Enter number of disks: "); // Prompt user to enter a number for the disks
        int number = in.nextInt();
        trickyHanoi(number, pegA, pegB, pegC);
    }
}