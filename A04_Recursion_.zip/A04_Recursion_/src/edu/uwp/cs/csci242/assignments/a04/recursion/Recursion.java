package edu.uwp.cs.csci242.assignments.a04.recursion;

import java.util.Stack;

/**
 * The purpose of this class is to show the multiple ways Recursion
 * can take complex problems and breaking them down into sub-problems.
 * </p>
 * This class is a problem set consisting of 5 small problems
 * to solve in isolation.
 * </p>
 * Each problem has a short recursive method to solve it,
 * with the exact same method signature(name, arguments, return type)
 * </p>
 * Each recursive solution is concise and short, and
 * will mirror each problem's inherent structure.
 * </p>
 *  @author Jordan Prica
 *  @edu.uwp.cs.242.courseCSCI 242 - Computer Science II
 *  @edu.uwp.cs.242.section 002
 *  @edu.uwp.cs.242.assignment 4
 *  Bugs: My program for Method 5: Tower of Hanoi, will print the number after
 *  it prints "Move disk"
 */
public class Recursion {

    /**
     * Default constructor
     */
    public Recursion(){

    }

    /**
     * Given a string, return, recursively, a "cleaned" string
     * where adjacent characters that are the same have been
     * reduced to a single character
     *
     * @param str string parameter
     * @return stringClean() reduced to a single character
     */
    public static String stringClean(String str) {
        // Base case: If the string is empty or has only one character, return it as is.
        if (str.length() < 2) {
            return str;
        }

        // Check if the first character is equal to the second character.
        if (str.charAt(0) == str.charAt(1)) {
            // If they are equal, skip the duplicate character and recurse on the rest of the string.
            return stringClean(str.substring(1));
        } else {
            // If they are not equal, keep the first character and recurse on the rest of the string.
            return str.charAt(0) + stringClean(str.substring(1));
        }
    }

    /**
     * The method countDigit() will count the number of times a particular
     * digit appears in a number n, where n > 0.
     * @param num integer that is positive
     * @param digit integer that appears in a positive integer
     * @return countDigit() will call until num becomes 0
     */
    public static int countDigit(int num, int digit){
        int d; // To hold the least significant digit
        if(num == 0) {
            return 0;
        }else {
            d = num % 10;
        }if(d == digit){
            return 1 + countDigit(num/10, digit);
        }
        return countDigit(num/10, digit);
    }

    /**
     * The method isBalanced() will take a string from which all characters except
     * the bracketing operators have been removed.
     * </p>
     * Function should return true if the bracketing operators in
     * the string are balanced (correctly nested and aligned).
     * </p>
     * This method will also implement 'Stack'.
     * @param str string that will hold all characters
     * @return isBalanced() stack size that will be balanced
     */
    public static boolean isBalanced(String str) {
        // 'open parentheses' - { [ (
        // 'close parentheses' - } ]
        // Stack will be placed to monitor 'Last in, First out'
        Stack<Character> stack = new Stack<>();

        for (char c : str.toCharArray()) {
            if (c == '(' || c == '[' || c == '{') {
                stack.push(c); // Push open brackets onto the stack.
            } else if (c == ')' || c == ']' || c == '}') {
                if (stack.isEmpty()) {
                    return false; // Unmatched close bracket, not balanced.
                }

                char top = stack.pop();
                if (!areMatching(top, c)) {
                    return false; // Mismatched open and close brackets, not balanced.
                }
            }
        }
        return stack.isEmpty(); // If the stack is empty, all brackets were matched and balanced.
    }
        private static boolean areMatching(char open, char close) {
            return (open == '(' && close == ')') || (open == '[' && close == ']') || (open == '{' && close == '}');
        }

        // make sure stack is empty, if not it's not balanced
       // return isBalanced(String.valueOf(stack.size() == 0));

    /**
     * The method splitArray will divide the ints into two groups,
     * so the sum of the two groups will be the same.
     * </p>
     * A recursive helper method will be used that takes 4 parameters:
     * the array, an index into the array, and two partial sums.
     * </p>
     * An initial call will be made to the helper from splitArray().
     * The helper method will make two recursive calls:
     * </p>
     * 1) where the current element is added onto the first sum,
     * 2) where the element is added onto the second sum.
     * If either returns true, the method returns true.
     *
     * @param array integer array
     * @return recursiveArray() will call to find combinations of splitting array
     */
    public static boolean splitArray(int [] array){
        int index = 0;
        int sum1 = 0;
        int sum2 = 0;

        return recArray(array, index, sum1, sum2);

    }

    /**
     * This is a helper method(below).
     * The purpose of this method is to split the elements of the array
     * </p>
     * The array is split into two groups, it will make 2 recursive calls
     * once it has found a way to split each group with equal sums.
     *
     * @param nums integer array
     * @param index index of the array
     * @param sum1 first integer sum
     * @param sum2 second integer sum
     * @return recArray() true if either of the two recursive calls returns true
     */
    private static boolean recArray (int[] nums, int index, int sum1, int sum2 ) {
        // Base case
        if ( index >= nums.length ) {
            return sum1 == sum2;
        }
        int value = nums[index];

        // If either is true this helper method will return true
        return (recArray(nums, index + 1, sum1 + value, sum2) ||
                recArray(nums, index + 1, sum1, sum2 + value));
    }

    /**
     * The goal of the game 'Tower of Hanoi' is to transfer all
     * the disks from peg A to peg C.
     * </p>
     * The only restriction is: only smaller disks can go on top
     * of larger disks.  This method will also contain a helper method.
     * @param disks to recurse and stack
     */
    public static void trickyHanoi(int disks, char source, char auxiliary, char target) {

        // Base case: If there's only one disk, move it from source to target through the auxiliary peg (B).
        if (disks == 1) {
            System.out.println("Move disk 1 from " + source + " to " + auxiliary);
            System.out.println("Move disk 1 from " + auxiliary + " to " + target);
        } else {
            // Move (disks - 1) disks from source to auxiliary using target as the auxiliary peg.
            trickyHanoi(disks - 1, source, target, auxiliary);

            // Move the remaining 1 disk from source to target.
            System.out.println("Move disk " + disks + " from " + source + " to " + auxiliary);
            System.out.println("Move disk " + disks + " from " + auxiliary + " to " + target);

            // Move (disks - 1) disks from auxiliary to target using source as the auxiliary peg.
            trickyHanoi(disks - 1, auxiliary, source, target);
        }

    }
}