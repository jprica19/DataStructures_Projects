package edu.uwp.cs.csci340.assignments.db;

import java.io.IOException;

/**
 * @author Jordan Prica
 * Class: CSCI-430
 * Project: A01-DB
 * </p>
 * This program implements a Skip List from scratch along with a customer parser
 * that is used for an in-memory database.
 * </p>
 * The project reinforces key concepts such as generics, persistence, serialization (via JSON),
 * and extensible, structured data models.
 * </p>
 * The purpose of this project is utilize Skip List as the core data structure for
 * logical indexing and data retrieval.
 * </p>
 * Class: Main- Initializes Database and CommandParser, then processes commands
 * from a specified input file.
 */
public class Main {
    /**
     * Runs the database application with commands from a file.
     * Expects a single command-line argument specifying the input file name.
     * If the argument is missing, prints a usage message and exits.
     *
     * @param args command-line arguments, expecting a single file name
     */
    public static void main(String[] args) throws IOException {
        if (args.length != 1) {
            System.err.println("Usage: java Main <input-file>");
            System.exit(1);
        }
        Database db = new Database();
        CommandParser parser = new CommandParser(db);
        parser.parseFile(args[0]);
    }
}