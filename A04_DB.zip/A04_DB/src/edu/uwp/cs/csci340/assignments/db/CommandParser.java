package edu.uwp.cs.csci340.assignments.db;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Class: CommandParser- A parser for database commands from a file.
 * This class reads commands from a file and executes them on a Database instance.
 * </p>
 * Supported commands include insert, delete, search, range, print, save, load, and drop.
 * The parser also is equipped to handle blank lines and comment lines.
 *
 */
public class CommandParser {
    private Database db;
    private boolean hasLoaded = false; // Track if a load has occurred

    public CommandParser(Database db) { // Constructor for given database
        this.db = db;
    }

    /**
     * Parses commands from a file and executes them on the database.
     * Each line in the file is treated as a single command. Blank lines and
     * lines starting with "//" are ignored.
     *
     * @param filename the name of the file containing commands
     * @throws IOException if an I/O error occurs while reading the file
     */
    public void parseFile(String filename) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                parseCommand(line.trim());
                System.out.println(); // Add newline for better output readability
            }
        }
    }

    /**
     * Parses and executes a single command.
     * Supports commands: insert, delete, search, range, print, save, load, and drop.
     * Handles error cases by printing appropriate error messages.
     *
     * @param command the command string to parse and execute
     */
    private void parseCommand(String command) {
        if (command.isEmpty() || command.startsWith("//")) return;

        // Split the command, preserving quoted parts with quotes
        String[] parts = splitCommand(command);
        if (parts.length == 0) {
            System.err.println("File parsing error: incomplete command line.");
            System.err.println("  Expecting: INSERT {key} {value}");
            return;
        }

        String cmd = parts[0].toLowerCase();
        switch (cmd) {
            case "insert":
                if (parts.length != 3) {
                    System.err.println("File parsing error: incomplete command line.");
                    System.err.println("  Expecting: INSERT {key} {value}");
                    return;
                }
                String keyPart = parts[1];  // Check if the key is a quoted string
                if (keyPart.startsWith("\"") && keyPart.endsWith("\"")) {
                    System.err.println("File parsing error: incompatible type in the command line.");
                    System.err.println("   Expecting: {key} integer {value} String.");
                    return;
                }
                if (!isInteger(keyPart)) {
                    System.err.println("File parsing error: incompatible type in the command line.");
                    System.err.println("   Expecting: {key} integer {value} String.");
                    return;
                }
                try {
                    int key = Integer.parseInt(keyPart);
                    String value = parts[2]; // Remove quotes from value if its present
                    if (value.startsWith("\"") && value.endsWith("\"")) {
                        value = value.substring(1, value.length() - 1);
                    }
                    db.dbInsert(key, value);
                } catch (NumberFormatException e) {
                    System.err.println("File parsing error: incompatible type in the command line.");
                    System.err.println("   Expecting: {key} integer {value} String.");
                }
                break;
            case "delete":
                if (parts.length != 2 || !isInteger(parts[1])) {
                    System.err.println("File parsing error: incomplete command line.");
                    System.err.println("  Expecting: DELETE {key}");
                    return;
                }
                db.dbDelete(Integer.parseInt(parts[1]));
                break;
            case "search":
                if (parts.length != 2 || !isInteger(parts[1])) {
                    System.err.println("File parsing error: incomplete command line.");
                    System.err.println("  Expecting: SEARCH {key}");
                    return;
                }
                db.dbSearch(Integer.parseInt(parts[1]));
                break;
            case "range":
                if (parts.length != 3 || !isInteger(parts[1]) || !isInteger(parts[2])) {
                    System.err.println("File parsing error: incomplete command line.");
                    System.err.println("  Expecting: RANGE {startKey} {endKey}");
                    return;
                }
                db.dbRange(Integer.parseInt(parts[1]), Integer.parseInt(parts[2]));
                break;
            case "print":
                if (parts.length != 1) {
                    System.err.println("File parsing error: incomplete command line.");
                    System.err.println("  Expecting: PRINT");
                    return;
                }
                db.dbPrint();
                break;
            case "save":
                if (parts.length != 2) {
                    System.err.println("File parsing error: incomplete command line.");
                    System.err.println("  Expecting: SAVE {filename}");
                    return;
                }
                try {
                    db.dbSaveToFile();
                    hasLoaded = false; // Reset hasLoaded after save
                } catch (IOException e) {
                    System.err.println("Error saving to file: " + e.getMessage());
                }
                break;
            case "load":
                if (parts.length != 2) {
                    System.err.println("File parsing error: incomplete command line.");
                    System.err.println("  Expecting: LOAD {filename}");
                    return;
                }
                try {
                    if (hasLoaded) { // Only save current state if modifications have occurred after first load
                        db.dbSaveToFile();
                    }
                    db.dbLoadFromFile();
                    hasLoaded = true;
                } catch (IOException e) {
                    System.err.println("Error loading from file: " + e.getMessage());
                }
                break;
            case "drop":
                if (parts.length != 1) {
                    System.err.println("File parsing error: incomplete command line.");
                    System.err.println("  Expecting: DROP");
                    return;
                }
                db.dbDrop();
                hasLoaded = false; // Reset hasLoaded after drop
                break;
            default:
                System.err.println("File parsing error: unknown command '" + parts[0] + "'.");
        }
    }

    /**
     * Splits a command string into parts, preserving quoted strings with quotes.
     *
     * @param command the command string to split
     * @return an array of command parts
     */
    private String[] splitCommand(String command) {
        List<String> parts = new ArrayList<>();
        StringBuilder currentPart = new StringBuilder();
        boolean inQuotes = false;

        for (int i = 0; i < command.length(); i++) {
            char c = command.charAt(i);
            if (c == '"') {
                inQuotes = !inQuotes;
                currentPart.append(c); // Include the quote in the part
                if (!inQuotes && currentPart.length() > 1) { // Ensure we have content inside quotes
                    parts.add(currentPart.toString());
                    currentPart = new StringBuilder();
                }
                continue;
            }
            if (c == ' ' && !inQuotes) {
                if (currentPart.length() > 0) {
                    parts.add(currentPart.toString());
                    currentPart = new StringBuilder();
                }
                continue;
            }
            currentPart.append(c);
        }

        if (currentPart.length() > 0) {
            parts.add(currentPart.toString());
        }

        return parts.toArray(new String[0]);
    }


    private boolean isInteger(String s) { // Checks if string can be parsed as an integer
        try {
            Integer.parseInt(s);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}