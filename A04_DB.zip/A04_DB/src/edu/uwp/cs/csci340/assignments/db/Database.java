package edu.uwp.cs.csci340.assignments.db;

import java.io.IOException;
import java.util.*;

/**
 * Class: Database- A database abstraction layer using a Skip List as the underlying data structure.
 * This abstraction encapsulates the Skip List's as its in-memory data structure.
 * </p>
 * The purpose is to efficiently manage data with probabilistic, multi-level linked lists
 * for optimized insertions, deletions, searches, and range queries.
 *
 */
public class Database {
    private SkipList<Integer, String> skipList;
    private static final String DEFAULT_FILE = "database.json";

    public Database() {
        this.skipList = new SkipList<>();
    } // Constructs an empty database with a new Skip List
                                                            // for underlying storage

    /**
     * Inserts a key-value pair into the database.
     * Prints a confirmation message upon successful insertion.
     *
     * @param key   the integer key to insert
     * @param value the string value associated with the key
     */
    public void dbInsert(Integer key, String value) {
        skipList.insert(key, value);
        System.out.println("(" + key + ", " + value + ") inserted.");
    }

    /**
     * Deletes a key from the database.
     * Prints a confirmation message upon deletion, even if the key was not found.
     *
     * @param key the integer key to delete
     */
    public void dbDelete(Integer key) {
        String value = skipList.search(key);
        if (value != null) {
            skipList.delete(key);
            System.out.println("key(" + key + ") deleted.");
        } else {
            System.out.println("key(" + key + ") deleted."); // Match sample output
        }
    }

    /**
     * Searches for a key in the database and prints the result.
     *
     * @param key the integer key to search for
     * @return the string value associated with the key, or null if not found
     */
    public String dbSearch(Integer key) {
        String value = skipList.search(key);
        System.out.print("key(" + key + ") searched... ");
        if (value != null) {
            System.out.println("value = " + value);
            return value;
        } else {
            System.out.println("Not found.");
            return null;
        }
    }

    /**
     * Returns all key-value pairs within a range of keys (inclusive) and prints the result.
     *
     * @param start the starting key of the range (inclusive)
     * @param end   the ending key of the range (inclusive)
     * @return a list of key-value pairs where the keys are between start and end
     */
    public List<Map.Entry<Integer, String>> dbRange(Integer start, Integer end) {
        List<Map.Entry<Integer, String>> range = skipList.rangeQuery(start, end);
        System.out.println("Range (" + start + "-" + end + "): " + formatRange(range));
        return range;
    }

    /**
     * Prints the database to System.out, showing the Skip List structure.
     */
    public void dbPrint() {
        System.out.println(skipList);
    }

    /**
     * Saves the database to a file in JSON format.
     * Prints a confirmation message upon successful saving.
     *
     * @throws IOException if an I/O error occurs while writing to the file
     */
    public void dbSaveToFile() throws IOException {
        skipList.saveToFile(DEFAULT_FILE);
        System.out.println("Saveing database to file...done."); // Match typo in sample output
    }

    /**
     * Loads the database from a JSON file.
     * Prints a confirmation message upon successful loading.
     *
     * @throws IOException if an I/O error occurs while reading the file
     */
    public void dbLoadFromFile() throws IOException {
        skipList.loadFromFile(DEFAULT_FILE);
        System.out.println("Loading database from file...done.");
    }

    /**
     * Drops the database, reinitializing it to an empty state.
     * Prints a confirmation message upon successful dropping.
     */
    public void dbDrop() {
        skipList = new SkipList<>();
        System.out.println("Dropping the database...done.");
    }

    /**
     * Formats a list of key-value pairs into a string representation for range queries.
     *
     * @param range the list of key-value pairs to format
     * @return a string representation of the range, e.g., "[key1=value1, key2=value2]"
     */
    private String formatRange(List<Map.Entry<Integer, String>> range) {
        if (range.isEmpty()) return "[]";
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < range.size(); i++) {
            Map.Entry<Integer, String> entry = range.get(i);
            sb.append(entry.getKey()).append("=").append(entry.getValue());
            if (i < range.size() - 1) sb.append(", ");
        }
        sb.append("]");
        return sb.toString();
    }
}