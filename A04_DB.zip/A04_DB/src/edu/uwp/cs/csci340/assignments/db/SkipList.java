package edu.uwp.cs.csci340.assignments.db;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.*;

/**
 * Class: SkipList- A generic Skip List implementation for an in-memory database.
 * managing key-value pairs.
 * </p>
 * Specifically insertion, deletion, searching and range querying while
 * maintaining a balance between performance and simplicity.
 * </p>
 * Includes level-based skipping for optimized access
 * and JSON-based persistence for data storage and retrieval.
 *
 * @param <K> the type of keys, must implement Comparable
 * @param <V> the type of values
 */
public class SkipList<K extends Comparable<K>, V> {

    /**
     * Inner class representing a node in the Skip List.
     * Each node contains a key, a value, and an array of forward pointers
     * for each level in the Skip List.
     *
     * @param <K> the type of the key
     * @param <V> the type of the value
     */
    private static class Node<K, V> {
        K key;
        V value;
        Node<K, V>[] next;


        @SuppressWarnings("unchecked")
        Node(K key, V value, int level) { // Constructs new node with the specified
            this.key = key;                 // key, value, and level
            this.value = value;
            this.next = new Node[level + 1];
        }
    }

    private Node<K, V> head;
    private int maxLevel;
    private int size;
    private Random random;

    /**
     * Constructs an empty Skip List with a maximum possible level of 32.
     * Initializes the head node as a sentinel with no key or value.
     * Seeds the random number generator for consistent level generation.
     */
    @SuppressWarnings("unchecked")
    public SkipList() {
        this.maxLevel = 0;
        this.size = 0;
        this.random = new Random(42); // Seed for consistent level generation
        this.head = new Node<>(null, null, 32); // Sentinel head with max possible levels
    }


    private int randomLevel() { // Generates a random level for a new node with a probabilistic approach
        int level = 0;
        while (random.nextDouble() < 0.75 && level < 32) { // Increased probability to 0.75
            level++; // Increasing the level is adjusted to ensure higher levels are generated
        }                   // more frequently, up to a max of 32
        return level;
    }

    @SuppressWarnings("unchecked")
    public void insert(K key, V value) { // Inserts a key-value pair into the Skip List
        Node<K, V>[] update = new Node[maxLevel + 1];
        Node<K, V> current = head;

        for (int i = maxLevel; i >= 0; i--) {
            while (current.next[i] != null && current.next[i].key.compareTo(key) < 0) {
                current = current.next[i];
            }
            update[i] = current;
        }

        current = current.next[0];
        if (current != null && current.key.compareTo(key) == 0) { // If key exists
            current.value = value;                // Update existing key
        } else {
            int newLevel = randomLevel();
            if (newLevel > maxLevel) { // Resize the update array to accommodate the new maximum level
                Node<K, V>[] newUpdate = new Node[newLevel + 1]; // Randomly assign level and insert into list
                System.arraycopy(update, 0, newUpdate, 0, maxLevel + 1);
                for (int i = maxLevel + 1; i <= newLevel; i++) {
                    newUpdate[i] = head;
                }
                update = newUpdate;
                maxLevel = newLevel;
            }
            Node<K, V> newNode = new Node<>(key, value, newLevel);
            for (int i = 0; i <= newLevel; i++) {
                newNode.next[i] = update[i].next[i];
                update[i].next[i] = newNode;
            }
            size++;
        }
    }

    @SuppressWarnings("unchecked")
    public void delete(K key) { // Deletes key from the Skip List
        Node<K, V>[] update = new Node[maxLevel + 1];
        Node<K, V> current = head;

        for (int i = maxLevel; i >= 0; i--) {
            while (current.next[i] != null && current.next[i].key.compareTo(key) < 0) {
                current = current.next[i];
            }
            update[i] = current;
        }

        current = current.next[0];
        if (current != null && current.key.compareTo(key) == 0) { // If key exists, remove the node
            for (int i = 0; i <= maxLevel; i++) {              // Adjust levels if necessary
                if (update[i].next[i] == current) {
                    update[i].next[i] = current.next[i];
                }
            }
            while (maxLevel > 0 && head.next[maxLevel] == null) {
                maxLevel--;
            }
            size--;
        }
    }

    public V search(K key) { // Searches for key in the Skip List
        Node<K, V> current = head;
        for (int i = maxLevel; i >= 0; i--) {
            while (current.next[i] != null && current.next[i].key.compareTo(key) < 0) {
                current = current.next[i];
            }
        }
        current = current.next[0];
        if (current != null && current.key.compareTo(key) == 0) {
            return current.value;
        }
        return null;
    }

    /**
     * Returns all key-value pairs within a range of keys (inclusive).
     *
     * @param key1 the start key of the range (inclusive)
     * @param key2 the end key of the range (inclusive)
     * @return a list of key-value pairs where the keys are between key1 and key2
     */
    public List<Map.Entry<K, V>> rangeQuery(K key1, K key2) {
        List<Map.Entry<K, V>> result = new ArrayList<>();
        Node<K, V> current = head;
        for (int i = maxLevel; i >= 0; i--) {
            while (current.next[i] != null && current.next[i].key.compareTo(key1) < 0) {
                current = current.next[i];
            }
        }
        current = current.next[0];
        while (current != null && current.key.compareTo(key2) <= 0) {
            result.add(new AbstractMap.SimpleEntry<>(current.key, current.value));
            current = current.next[0];
        }
        return result;
    }

    /**
     * Saves the Skip List to a file in JSON format.
     * The key-value pairs are serialized into a JSON object and written to the specified file.
     *
     * @param filename the name of the file to save to
     * @throws IOException if an I/O error occurs while writing to the file
     */
    public void saveToFile(String filename) throws IOException {
        Map<K, V> map = new HashMap<>();
        Node<K, V> current = head.next[0];
        while (current != null) {
            map.put(current.key, current.value);
            current = current.next[0];
        }
        try (FileWriter writer = new FileWriter(filename)) {
            new Gson().toJson(map, writer);
        }
    }

    /**
     * Loads the Skip List from a JSON file.
     * The file is expected to contain a JSON object mapping keys to values.
     * The Skip List is cleared and repopulated with the data from the file.
     * Handles key conversion for Integer keys since JSON keys are strings.
     *
     * @param filename the name of the file to load from
     * @throws IOException if an I/O error occurs while reading the file
     */
    @SuppressWarnings("unchecked")
    public void loadFromFile(String filename) throws IOException {
        try (FileReader reader = new FileReader(filename)) {
            // Deserialize JSON into a Map<String, V> since JSON keys are strings
            Type type = new TypeToken<Map<String, V>>(){}.getType();
            Map<String, V> rawMap = new Gson().fromJson(reader, type);
            if (rawMap == null || rawMap.isEmpty()) {
                System.err.println("Warning: No data loaded from " + filename + ". File might be empty or corrupted.");
                return;
            }
            head = new Node<>(null, null, 32);
            maxLevel = 0;
            size = 0;
            for (Map.Entry<String, V> entry : rawMap.entrySet()) {
                try {
                    // Since K should be Integer in this context, convert the string key to Integer
                    Integer key = Integer.parseInt(entry.getKey());
                    insert((K) key, entry.getValue());
                } catch (NumberFormatException e) {
                    System.err.println("Error: Invalid key format in JSON data for key " + entry.getKey() + ": " + e.getMessage());
                } catch (ClassCastException e) {
                    System.err.println("Error: Type mismatch in JSON data for key " + entry.getKey() + ": " + e.getMessage());
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading from file: " + e.getMessage());
            throw new IOException("Failed to load from file: " + e.getMessage(), e);
        }
    }

    @Override
    public String toString() { // Returns a string representation of the Skip List
        // Structure displayed level by level, showing the keys at each level
        StringBuilder sb = new StringBuilder("SkipList Database:\n");
        for (int i = maxLevel; i >= 0; i--) {
            sb.append("Level ").append(i).append(": ");
            Node<K, V> current = head.next[i];
            if (current == null) {
                sb.append("null\n");
            } else {
                while (current != null) {
                    sb.append("[ ").append(current.key).append(" ] -> ");
                    current = current.next[i];
                }
                sb.append("null\n");
            }
        }
        return sb.toString();
    }
}