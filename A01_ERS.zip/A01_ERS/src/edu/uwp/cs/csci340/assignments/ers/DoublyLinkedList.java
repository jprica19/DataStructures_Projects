package edu.uwp.cs.csci340.assignments.ers;
/**
 * Class: DoublyLinkedList- A generic positional doubly linked list with sentinel nodes.
 *</p>
 * @param <E> the type of elements in the list
 */


public class DoublyLinkedList<E> {


    private static class Node<E> { // Nested node class
        E element;
        Node<E> prev;
        Node<E> next;


        /**
         * This method creates a node with the given element and links.
         *
         * @param element the element to store
         * @param prev    previous node
         * @param next    next node
         */
        Node(E element, Node<E> prev, Node<E> next) {
            this.element = element;
            this.prev = prev;
            this.next = next;
        }
    }



    public class Position { // Position class to access elements
        private Node<E> node;


        private Position(Node<E> node) { // Creates position for given node
            this.node = node;
        }

        public E getElement() { // Retrieves element for this position
            if (node == header || node == trailer) throw new IllegalStateException("Invalid position");
            return node.element;
        }

        private Node<E> getNode() { // Gets private node at this position
            return node;
        }
    }


    private Node<E> header;
    private Node<E> trailer;
    private int size;


    /** Creates an empty doubly linked list with sentinels. */
    public DoublyLinkedList() {
        header = new Node<>(null, null, null);
        trailer = new Node<>(null, header, null);
        header.next = trailer;
        size = 0;
    }


    public int size() {
        return size;
    } // Returns the number of elements in the list


    public boolean isEmpty() {
        return size == 0;
    } // Checks if the list is empty

    public Position first() { // Returns position of first element, or null (if empty)
        if (isEmpty()) return null;
        return new Position(header.next);
    }

    public Position last() { // Returns position of last element or null (if empty)
        if (isEmpty()) return null;
        return new Position(trailer.prev);
    }

    public Position addFirst(E element) {  // Adds an element at the start of the list
        return addBetween(element, header, header.next);
    }

    public Position addLast(E element) { // Adds an element at the end of the list
        return addBetween(element, trailer.prev, trailer);
    }

    public Position addAfter(Position p, E element) { // Adds an element AFTER the given position
        Node<E> node = validate(p);
        return addBetween(element, node, node.next);
    }

    public Position addBefore(Position p, E element) { // Adds element BEFORE given position
        Node<E> node = validate(p);
        return addBetween(element, node.prev, node);
    }

    public E remove(Position p) { // Removes element at given position
        Node<E> node = validate(p);
        Node<E> pred = node.prev;
        Node<E> succ = node.next;
        pred.next = succ;
        succ.prev = pred;
        size--;
        E element = node.element;
        node.element = null; // Help garbage collection
        node.prev = node.next = null;
        return element;
    }


    public Position after(Position p) { // Returns position after the given position
        Node<E> node = validate(p);
        if (node.next == trailer) return null;
        return new Position(node.next);
    }


    public Position before(Position p) { // Returns position before the given position
        Node<E> node = validate(p);
        if (node.prev == header) return null;
        return new Position(node.prev);
    }


    private Position addBetween(E element, Node<E> pred, Node<E> succ) { // Adds an element between two nodes
        Node<E> newNode = new Node<>(element, pred, succ);
        pred.next = newNode;
        succ.prev = newNode;
        size++;
        return new Position(newNode);
    }


    /**
     * Validates a position and returns its node.
     * </p>
     * @param p the position to validate
     * @return the node at the position
     * @throws IllegalArgumentException if position is invalid
     */
    private Node<E> validate(Position p) {
        if (p == null || p.node == null || p.node == header || p.node == trailer) {
            throw new IllegalArgumentException("Invalid position");
        }
        return p.node;
    }
}

