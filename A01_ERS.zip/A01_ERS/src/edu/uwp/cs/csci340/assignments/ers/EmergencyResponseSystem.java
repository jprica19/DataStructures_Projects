package edu.uwp.cs.csci340.assignments.ers;
/**
 * @author: Jordan Prica
 * Class: CSCI-430
 * Project: A01-RSA
 * </p>
 * This program implements a doubly linked list and a priority queue without using Java collection classes.
 * The purpose is to apply the priority queue to an Emergency Response System; a real-world application.
 * </p>
 * The classes and components within the Emergency Response System include:
 * Real-Time Updates, Incident Management, Resource Allocation, Communication Tools, and Mapping.
 * </p>
 * Goal: Open, Read, Insert, and Remove incidents from the Priority Queue while keeping severity of incidents
 * in mind.
 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class EmergencyResponseSystem {
    public static void main(String[] args) {
        // Reset the ID counter to ensure consistent IDs
        EmergencyIncident.setIdCounter(0);

        PriorityQueueImpl<Integer, EmergencyIncident> pq = new PriorityQueueImpl<>();

        // Part 1: Process incidents from CSV file (required by assignment)
        System.out.println("Adding emergency incidents to the emergency queue... [Complete]");
        System.out.println("Processing emergency incidents in order of priority:\n");

        try (BufferedReader br = new BufferedReader(new FileReader("/Users/jordanprica/Desktop/Data_Structures/A01_ERS/incidents.csv"))) {
            String line;
            boolean firstLine = true;
            while ((line = br.readLine()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue; // Skip header line
                }
                String[] data = line.split(",");
                if (data.length == 4) {
                    int incidentID = Integer.parseInt(data[0]);
                    String incidentType = data[1];
                    int severityLevel = Integer.parseInt(data[2]);
                    int location = Integer.parseInt(data[3]);
                    int responseTime = calculateResponseTime(location);
                    EmergencyIncident ei = new EmergencyIncident(incidentType, severityLevel, responseTime, location);
                    ei.setIncidentID(incidentID); // Ensure ID matches the file
                    pq.insert(severityLevel, ei); // Using severity as the key
                }
            }

            while (!pq.isEmpty()) {
                EmergencyIncident ei = pq.removeMin();
                System.out.println(ei);
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }

        // Part 2: Test EmergencyIncident comparison (additional test code)
        System.out.println("\n--- Testing EmergencyIncident Comparison ---\n");

        // Reset the ID counter for the test incidents
        EmergencyIncident.setIdCounter(0);

        // Create test incidents
        EmergencyIncident inc1 = new EmergencyIncident("fire", 1, 5, 5);
        EmergencyIncident inc2 = new EmergencyIncident("medical", 1, 10, 12);
        EmergencyIncident inc3 = new EmergencyIncident("accident", 2, 7, 8);

        // Print incident details
        System.out.println("Incident 1:\n" + inc1);
        System.out.println("Incident 2:\n" + inc2);
        System.out.println("Incident 3:\n" + inc3);

        // Test comparisons
        System.out.println("Comparison (inc1 vs inc2): " + inc1.compareTo(inc2)); // Should be negative (same severity, lower response time)
        System.out.println("Comparison (inc2 vs inc3): " + inc2.compareTo(inc3)); // Should be negative (lower severity)
    }

    private static int calculateResponseTime(int location) {
        switch (location) {
            case 2: return 5;  // Auden Winstone residence
            case 5: return 5;  // Brock Wynnee residence
            case 8: return 7;  // North Island Hospital
            case 11: return 10; // Graham Medical
            case 12: return 10; // Stortward School
            case 16: return 15; // Harper Vanne's Fish Market
            case 17: return 13; // Caulfielde's Supermarket
            case 22: return 15; // Downtown Stortward
            default: return 10; // Default response time
        }
    }
}
