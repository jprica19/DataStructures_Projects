package edu.uwp.cs.csci340.assignments.ers;

/**
 * Interface: PriorityQueue- defines a generic priority queue ADT with methods to insert entries, remove the minimum,
 * and access the minimum entry based on key priority.
 */
public interface PriorityQueue<K, V> {
    int size();
    boolean isEmpty();
    void insert(K key, V value);
    V removeMin();
    V min();
}
