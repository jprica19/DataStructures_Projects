package edu.uwp.cs.csci340.assignments.ers;

/**
 * Class: EmergencyIncident- stores emergency incident details (ID, type, severity, response time, location)
 * and formats them for output with location and district mappings.
 * </p>
 * Uses Comparable to prioritize incidents by comparing severity (1-5, 1 highest) first, then response
 * time (lower first) for sorting in a priority queue.
 */
public class EmergencyIncident implements Comparable<EmergencyIncident> {
    private static int idCounter = 0;
    private int incidentID;
    private String incidentType;
    private int severityLevel;
    private int responseTime;
    private int location;


    // Arrays for location and district mappings (instead of HashMap)
    private static final int[] LOCATION_IDS = {2, 5, 8, 11, 12, 16, 17, 22};
    private static final String[] LOCATION_NAMES = {
            "Auden Winstone residence",
            "Brock Wynnee residence",
            "North Island Hospital",
            "Graham Medical",
            "Stortward School",
            "Harper Vanne's Fish Market",
            "Caulfielde's Supermarket",
            "Downtown Stortward"
    };
    private static final String[] DISTRICT_NAMES = { // Arrays for the names of the districts
            "Residential District",
            "Residential District",
            "Fishing District",
            "Industrial District",
            "Industrial District",
            "South Pier District",
            "Downtown",
            "South Pier District"
    };

    /**
     * Constructs a new EmergencyIncident with the specified attributes.
     *
     * @param incidentType  the type of the incident (e.g., "fire", "medical")
     * @param severityLevel the severity level (1-5, where 1 is highest)
     * @param responseTime  the estimated response time in minutes
     * @param location      the location ID of the incident
     */
    public EmergencyIncident(String incidentType, int severityLevel, int responseTime, int location) {
        this.incidentID = ++idCounter;
        this.incidentType = incidentType;
        this.severityLevel = severityLevel;
        this.responseTime = responseTime;
        this.location = location;
    }


    /**
     * Compares this EmergencyIncident with another based on severity (primary) and
     * response time (secondary). Higher severity (lower numerical value) takes
     * priority; if severities are equal, lower response time takes priority.
     *</p>
     * @param other the EmergencyIncident to compare to
     * @return a negative integer, zero, or a positive integer as this object
     * is less than, equal to, or greater than the specified object
     */
    @Override
    public int compareTo(EmergencyIncident other) {
        int severityComparison = Integer.compare(this.severityLevel, other.severityLevel);
        if (severityComparison != 0) {
            return severityComparison;
        }
        return Integer.compare(this.responseTime, other.responseTime);
    }


    // Getters
    public static int getIdCounter() {
        return idCounter;
    }

    public int getIncidentID() {
        return incidentID;
    }

    public String getIncidentType() {
        return incidentType;
    }

    public int getSeverityLevel() {
        return severityLevel;
    }

    public int getResponseTime() {
        return responseTime;
    }

    public int getLocation() {
        return location;
    }


    // Setters
    public static void setIdCounter(int idCounter) {
        EmergencyIncident.idCounter = idCounter;
    }

    public void setIncidentID(int incidentID) {
        this.incidentID = incidentID;
    }

    public void setIncidentType(String incidentType) {
        this.incidentType = incidentType;
    }

    public void setSeverityLevel(int severityLevel) {
        this.severityLevel = severityLevel;
    }

    public void setResponseTime(int responseTime) {
        this.responseTime = responseTime;
    }

    public void setLocation(int location) {
        this.location = location;
    }


    /**
     * Returns a string representation of the EmergencyIncident.
     *</p>
     * @return a string containing the incident details
     */
    @Override
    public String toString() {
        String severityText = getSeverityText(severityLevel);
        String locationName = getLocationName(location);
        String district = getDistrictName(location);
        return String.format(
                "2025-03-13T12:00:00%n" +
                        "  | ID: %d%n" +
                        "  | Type: %s%n" +
                        "  | Severity: %s(%d)%n" +
                        "  | Location: %s(%d)%n" +
                        "  | District: %s%n" +
                        "  | Response Time: %d minutes%n" +
                        "  +----------",
                incidentID, incidentType, severityText, severityLevel, locationName, location,
                district, responseTime
        );
    }


    /**
     * Helper method to convert severity level to a textual representation.
     *</p>
     * @param level the severity level (1-5)
     * @return the textual representation of the severity
     */
    private String getSeverityText(int level) {
        switch (level) {
            case 1:
                return "High";
            case 2:
                return "Medium-High";
            case 3:
                return "Medium";
            case 4:
                return "Medium-Low";
            case 5:
                return "Low";
            default:
                return "Unknown";
        }
    }


    /**
     * Retrieves the location name based on the location ID.
     *</p>
     * @param location the location ID
     * @return the location name, or a default if not found
     */
    private String getLocationName(int location) {
        for (int i = 0; i < LOCATION_IDS.length; i++) {
            if (LOCATION_IDS[i] == location) {
                return LOCATION_NAMES[i];
            }
        }
        return "Unknown Location " + location;
    }


    /**
     * Retrieves the district name based on the location ID.
     *</p>
     * @param location the location ID
     * @return the district name, or a default if not found
     */
    private String getDistrictName(int location) {
        for (int i = 0; i < LOCATION_IDS.length; i++) {
            if (LOCATION_IDS[i] == location) {
                return DISTRICT_NAMES[i];
            }
        }
        return "Unknown District";
    }
}