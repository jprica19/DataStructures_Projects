package edu.uwp.cs.csci340.assignments.ers;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

/**
 * Class: GenerateIncidents- generates a specified number of random emergency incidents and writes them to a CSV file
 * named incidents.csv.
 * </p>
 * Format includes: incidentID,incidentType,incidentSeverity,incidentLocation along with a timestamp
 */
public class GenerateIncidents {
    private static final int NUM_INCIDENTS = 10;
    private static final String[] INCIDENT_TYPES = {"fire", "medical", "accident"};
    private static final Random RANDOM = new Random();
    private static final int MIN_SEVERITY = 1;
    private static final int MAX_SEVERITY = 4;
    private static final int MIN_LOCATION = 2;
    private static final int MAX_LOCATION = 22;

    public static void main(String[] args) {
        try {
            System.out.println("Generating " + NUM_INCIDENTS + " Incidents...");
            System.out.println("Initializing... [Complete]");
            System.out.println("Opening output file... [Complete]");
            generateIncidentsFile();
            System.out.println("Generating CSV file... [Complete]");
            System.out.println("DONE.");
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }
    }

    private static void generateIncidentsFile() throws IOException {
        // Absolute filepath to write the attributes to the incidents.csv
        try (FileWriter writer = new FileWriter("/Users/jordanprica/Desktop/Data_Structures/A01_ERS/incidents.csv")) {
            writer.write("incidentID,incidentType,incidentSeverity,incidentLocation\n");
            for (int id = 1; id <= NUM_INCIDENTS; id++) {
                String type = INCIDENT_TYPES[RANDOM.nextInt(INCIDENT_TYPES.length)];
                int severity = RANDOM.nextInt(MAX_SEVERITY - MIN_SEVERITY + 1) + MIN_SEVERITY;
                int location = RANDOM.nextInt(MAX_LOCATION - MIN_LOCATION + 1) + MIN_LOCATION;
                writer.write(String.format("%d,%s,%d,%d\n", id, type, severity, location));
            }
        }
    }
}