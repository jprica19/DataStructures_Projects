package edu.uwp.cs.csci340.assignments.ers;

/**
 * Class: PriorityQueueImpl- implements a generic priority queue using a DoublyLinkedList to store entries in sorted order
 * by key, supporting insertion, removal, and access of the minimum entry based on priority.
 *</p>
 * @param <K> the type of keys (priority)
 * @param <V> the type of values
 * @author [Your Name]
 * @version 1.0
 */
class PriorityQueueImpl<K extends Comparable<K>, V> extends AbstractPriorityQueue<K, V> {
    private DoublyLinkedList<Entry<K, V>> list;


    public PriorityQueueImpl() {
        list = new DoublyLinkedList<>();
    }


    @Override
    public int size() {
        return list.size();
    }


    @Override
    public boolean isEmpty() {
        return list.isEmpty();
    }


    @Override
    public void insert(K key, V value) {
        Entry<K, V> newEntry = new Entry<>(key, value);
        if (list.isEmpty()) {
            list.addFirst(newEntry);
            return;
        }


        // Insert in sorted order by key (ascending)
        DoublyLinkedList<Entry<K, V>>.Position p = list.first();
        while (p != null && p.getElement().key.compareTo(key) <= 0) {
            p = list.after(p);
        }


        if (p == null) {
            list.addLast(newEntry);
        } else {
            list.addBefore(p, newEntry);
        }
    }


    @Override
    public V removeMin() {
        if (isEmpty()) throw new IllegalStateException("Priority queue is empty");
        return list.remove(list.first()).value;
    }


    @Override
    public V min() {
        if (isEmpty()) throw new IllegalStateException("Priority queue is empty");
        return list.first().getElement().value;
    }
}

