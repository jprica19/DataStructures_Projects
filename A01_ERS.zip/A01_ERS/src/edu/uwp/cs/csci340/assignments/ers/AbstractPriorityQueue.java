package edu.uwp.cs.csci340.assignments.ers;

/**
 * Class: AbsolutePriorityQueue- Provides a base implementation for a generic priority queue, including a nested Entry class
 * to store key-value pairs.
 *</p>
 * @param <K> the type of keys (priority)
 * @param <V> the type of values
 */
public abstract class AbstractPriorityQueue<K, V> implements PriorityQueue<K, V> {
    protected static class Entry<K, V> {
        K key;
        V value;


        Entry(K key, V value) { // Instantiation
            this.key = key;
            this.value = value;
        }
    }
}



